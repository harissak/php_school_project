<html>
<head>
    <meta charset="utf8">
    <link rel="stylesheet" href="../style.css">
   
    <title>SCRRABLE</title>
    <link rel="icon" href="" type="">
</head>

<body>
<form action="../Controller/searchRequest.php" method="post">  
    <input type="text" name="search" placeholder="Enter text"> 
    <button type="submit" name="submit">Search</button>
    </form>
</body>
</html>