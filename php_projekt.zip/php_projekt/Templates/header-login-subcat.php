<html>
<head>
    <meta charset="utf8">
    <link rel="stylesheet" href="../style.css">
   
    <title>SCRRABLE</title>
    <link rel="icon" href="" type="">
</head>

<body>

<nav>
<div class="nav-links">
<ul>

<li><a href="login-view.php">Log in</a></li>
 
</ul>
</div>
</nav>
</body>

</html>