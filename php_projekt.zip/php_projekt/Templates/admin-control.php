<html>
<head>
    <meta charset="utf8">
    <link rel="stylesheet" href="../style.css">
   
    <title>SCRRABLE</title>
    <link rel="icon" href="" type="">
</head>

<body>

<form action="../Controller/insert.php" method="post">  
    <input type="submit" name="insert" value="insert"> 
    
</form>

</body>

</html>