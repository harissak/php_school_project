
<html>
<head>
    <meta charset="utf8">
    <link rel="stylesheet" href="../style.css">
   
    <title>SCRRABLE</title>
    <link rel="icon" href="" type="">
</head>

<body>

<nav>
<a href="index.php"> <img src="" alt=""></a>
<div class="nav-links" id="navLinks">
    <ul>
        <li><a href="../index.php">HOME</a></li>
        <li><a href="club-view.php">CLUB</a></li>
        <li><a href="categories-view.php">CATEGORIE</a></li>
        <li><a href="judge-view.php">JUDGE/ARBITRE</a></li>
        <li><a href="membre-view.php">MEMBRE</a></li>
        <li><a href="turnoi-view.php">TURNOI</a></li>
        <li><a href="participer-view.php">RESULT</a></li>
    </ul>
</div>
</nav>

</body>

</html>