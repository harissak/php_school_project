<?php
session_start();

echo $_SESSION['logID'];
echo $_SESSION['role'];

?>