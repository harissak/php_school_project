<?php
$hn = 'localhost';
$db = 'scrabble';
$un = 'root';
$pw = 'mysql';

?>